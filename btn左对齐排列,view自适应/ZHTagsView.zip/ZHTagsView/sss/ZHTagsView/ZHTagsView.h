//
//  ZHTagsView.h
//  sss
//
//  Created by xyj on 17/5/11.
//  Copyright © 2017年 xyj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZHTagsView : UIView
@property (nonatomic,strong) NSArray *dataArray;
-(CGFloat)viewForHeight;
@end
