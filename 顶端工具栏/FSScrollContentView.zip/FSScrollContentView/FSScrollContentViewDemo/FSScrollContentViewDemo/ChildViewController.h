//
//  ChildViewController.h
//  FSScrollContentViewDemo
//
//  Created by 冯顺 on 2017/5/3.
//  Copyright © 2017年 fengshun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChildViewController : UIViewController

@property (nonatomic, strong) NSString *titleStr;
@end
